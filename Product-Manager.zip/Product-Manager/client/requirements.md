## Packages
recharts | Dashboard charts and analytics
xlsx | Export reports to Excel
jspdf | Export reports to PDF
jspdf-autotable | Table plugin for PDF export
framer-motion | Animations for polished UI transitions
date-fns | Date formatting and manipulation

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
