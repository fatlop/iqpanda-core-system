import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { insertProductSchema, insertSupplierSchema } from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // === PRODUCTS ===
  app.get(api.products.list.path, async (req, res) => {
    const activeOnly = req.query.activeOnly !== 'false';
    const products = await storage.getProducts(activeOnly);
    res.json(products);
  });

  app.get(api.products.get.path, async (req, res) => {
    const product = await storage.getProduct(Number(req.params.id));
    if (!product) return res.status(404).json({ message: "Product not found" });
    res.json(product);
  });

  app.post(api.products.create.path, async (req, res) => {
    try {
      const input = insertProductSchema.parse(req.body);
      const product = await storage.createProduct(input);
      res.status(201).json(product);
    } catch (e) {
      if (e instanceof z.ZodError) {
        return res.status(400).json({ message: e.errors[0].message });
      }
      throw e;
    }
  });

  app.put(api.products.update.path, async (req, res) => {
    try {
      const input = insertProductSchema.partial().parse(req.body);
      const product = await storage.updateProduct(Number(req.params.id), input);
      res.json(product);
    } catch (e) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  app.delete(api.products.delete.path, async (req, res) => {
    await storage.deleteProduct(Number(req.params.id));
    res.status(204).end();
  });

  // === SUPPLIERS ===
  app.get(api.suppliers.list.path, async (req, res) => {
    const suppliers = await storage.getSuppliers();
    res.json(suppliers);
  });

  app.post(api.suppliers.create.path, async (req, res) => {
    const input = insertSupplierSchema.parse(req.body);
    const supplier = await storage.createSupplier(input);
    res.status(201).json(supplier);
  });

  app.put(api.suppliers.update.path, async (req, res) => {
    const input = insertSupplierSchema.partial().parse(req.body);
    const supplier = await storage.updateSupplier(Number(req.params.id), input);
    res.json(supplier);
  });

  app.delete(api.suppliers.delete.path, async (req, res) => {
    await storage.deleteSupplier(Number(req.params.id));
    res.status(204).end();
  });

  // === SALES ===
  app.post(api.sales.create.path, async (req, res) => {
    try {
      const sale = await storage.createSale(req.body);
      res.status(201).json(sale);
    } catch (e: any) {
      res.status(400).json({ message: e.message || "Failed to create sale" });
    }
  });

  app.get(api.sales.list.path, async (req, res) => {
    const start = req.query.startDate ? new Date(req.query.startDate as string) : undefined;
    const end = req.query.endDate ? new Date(req.query.endDate as string) : undefined;
    const sales = await storage.getSales(start, end);
    res.json(sales);
  });

  app.get(api.sales.report.path, async (req, res) => {
    const period = req.query.period as 'daily' | 'weekly' | 'monthly';
    const report = await storage.getSalesReport(period);
    res.json(report);
  });

  // Seed Data
  await seedData();

  return httpServer;
}

async function seedData() {
  const products = await storage.getProducts();
  if (products.length === 0) {
    console.log("Seeding database...");
    const supplier = await storage.createSupplier({
      name: "Global Tech Supplies",
      contactName: "John Doe",
      email: "john@globaltech.com",
      phone: "555-0123",
      address: "123 Tech Blvd"
    });

    await storage.createProduct({
      name: "Wireless Mouse",
      description: "Ergonomic 2.4G wireless mouse",
      sku: "MS-001",
      price: "25.00",
      cost: "12.00",
      stock: 50,
      supplierId: supplier.id,
      active: true
    });

    await storage.createProduct({
      name: "Mechanical Keyboard",
      description: "RGB Mechanical Keyboard Blue Switch",
      sku: "KB-002",
      price: "89.99",
      cost: "45.00",
      stock: 20,
      supplierId: supplier.id,
      active: true
    });

    await storage.createProduct({
      name: "USB-C Hub",
      description: "7-in-1 USB-C Multiport Adapter",
      sku: "HUB-003",
      price: "45.00",
      cost: "20.00",
      stock: 35,
      supplierId: supplier.id,
      active: true
    });
  }
}
