import { 
  products, suppliers, sales, saleItems,
  type Product, type InsertProduct,
  type Supplier, type InsertSupplier,
  type Sale, type InsertSale,
  type SaleItem, type InsertSaleItem,
  type CreateSaleRequest,
  type SalesReport
} from "@shared/schema";
import { db } from "./db";
import { eq, like, and, gte, lte, sql, desc } from "drizzle-orm";

export interface IStorage {
  // Products
  getProducts(activeOnly?: boolean): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product>;
  deleteProduct(id: number): Promise<void>;

  // Suppliers
  getSuppliers(): Promise<Supplier[]>;
  getSupplier(id: number): Promise<Supplier | undefined>;
  createSupplier(supplier: InsertSupplier): Promise<Supplier>;
  updateSupplier(id: number, supplier: Partial<InsertSupplier>): Promise<Supplier>;
  deleteSupplier(id: number): Promise<void>;

  // Sales
  createSale(sale: CreateSaleRequest): Promise<Sale>;
  getSales(startDate?: Date, endDate?: Date): Promise<(Sale & { items: SaleItem[] })[]>;
  getSalesReport(period: 'daily' | 'weekly' | 'monthly', date?: Date): Promise<SalesReport[]>;
}

export class DatabaseStorage implements IStorage {
  // === PRODUCTS ===
  async getProducts(activeOnly = true): Promise<Product[]> {
    if (activeOnly) {
      return await db.select().from(products).where(eq(products.active, true)).orderBy(products.name);
    }
    return await db.select().from(products).orderBy(products.name);
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const [product] = await db.insert(products).values(insertProduct).returning();
    return product;
  }

  async updateProduct(id: number, update: Partial<InsertProduct>): Promise<Product> {
    const [product] = await db.update(products).set(update).where(eq(products.id, id)).returning();
    return product;
  }

  async deleteProduct(id: number): Promise<void> {
    // Soft delete
    await db.update(products).set({ active: false }).where(eq(products.id, id));
  }

  // === SUPPLIERS ===
  async getSuppliers(): Promise<Supplier[]> {
    return await db.select().from(suppliers).where(eq(suppliers.active, true));
  }

  async getSupplier(id: number): Promise<Supplier | undefined> {
    const [supplier] = await db.select().from(suppliers).where(eq(suppliers.id, id));
    return supplier;
  }

  async createSupplier(insertSupplier: InsertSupplier): Promise<Supplier> {
    const [supplier] = await db.insert(suppliers).values(insertSupplier).returning();
    return supplier;
  }

  async updateSupplier(id: number, update: Partial<InsertSupplier>): Promise<Supplier> {
    const [supplier] = await db.update(suppliers).set(update).where(eq(suppliers.id, id)).returning();
    return supplier;
  }

  async deleteSupplier(id: number): Promise<void> {
    await db.update(suppliers).set({ active: false }).where(eq(suppliers.id, id));
  }

  // === SALES ===
  async createSale(request: CreateSaleRequest): Promise<Sale> {
    // Calculate total and prepare items
    let total = 0;
    const itemsToInsert: { productId: number; quantity: number; price: string }[] = [];

    // 1. Validate stock and calculate total (in a real app, use a transaction)
    for (const item of request.items) {
      const product = await this.getProduct(item.productId);
      if (!product) throw new Error(`Product ${item.productId} not found`);
      if ((product.stock || 0) < item.quantity) throw new Error(`Insufficient stock for ${product.name}`);
      
      const price = product.price; // Use current price
      total += Number(price) * item.quantity;
      itemsToInsert.push({
        productId: item.productId,
        quantity: item.quantity,
        price: price.toString()
      });
    }

    return await db.transaction(async (tx) => {
      // 2. Create Sale
      const [sale] = await tx.insert(sales).values({
        total: total.toString(),
        paymentMethod: request.paymentMethod
      }).returning();

      // 3. Create Sale Items & Update Stock
      for (const item of itemsToInsert) {
        await tx.insert(saleItems).values({
          saleId: sale.id,
          productId: item.productId,
          quantity: item.quantity,
          price: item.price
        });

        // Decrement stock
        await tx.execute(sql`
          UPDATE products 
          SET stock = stock - ${item.quantity}
          WHERE id = ${item.productId}
        `);
      }

      return sale;
    });
  }

  async getSales(startDate?: Date, endDate?: Date): Promise<(Sale & { items: SaleItem[] })[]> {
    const conditions = [];
    if (startDate) conditions.push(gte(sales.createdAt, startDate));
    if (endDate) conditions.push(lte(sales.createdAt, endDate));

    const salesList = await db.select().from(sales)
      .where(and(...conditions))
      .orderBy(desc(sales.createdAt));

    // Fetch items (N+1 query is okay for small scale, join is better but more complex to type here quickly)
    // For "lite" build, let's just return sales for now or do a simple join if needed.
    // Actually, let's fetch items separately and map them in memory for simplicity/speed
    
    const result: (Sale & { items: SaleItem[] })[] = [];
    
    for (const sale of salesList) {
      const items = await db.select().from(saleItems).where(eq(saleItems.saleId, sale.id));
      result.push({ ...sale, items });
    }
    
    return result;
  }

  async getSalesReport(period: 'daily' | 'weekly' | 'monthly', date: Date = new Date()): Promise<SalesReport[]> {
    // This is a simplified reporting query. 
    // In postgres we can use date_trunc.
    
    let truncation: 'day' | 'week' | 'month' = 'day';
    if (period === 'weekly') truncation = 'week';
    if (period === 'monthly') truncation = 'month';

    const result = await db.execute(sql`
      SELECT 
        DATE_TRUNC(${truncation}, created_at) as date,
        SUM(total) as total_sales,
        COUNT(id) as count
      FROM sales
      GROUP BY DATE_TRUNC(${truncation}, created_at)
      ORDER BY date DESC
      LIMIT 30
    `);

    return result.rows.map(row => ({
      date: new Date(row.date as string).toISOString(),
      totalSales: Number(row.total_sales),
      count: Number(row.count)
    }));
  }
}

export const storage = new DatabaseStorage();
